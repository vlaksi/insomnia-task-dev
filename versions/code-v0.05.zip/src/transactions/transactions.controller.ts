import {
  BadRequestException,
  Controller,
  Get,
  InternalServerErrorException,
  Query,
  Logger,
  NotFoundException,
  Param,
} from '@nestjs/common';
import { TransactionsService } from './transactions.service';
import {
  ApiOperation,
  ApiParam,
  ApiQuery,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
@ApiTags('USDC Transactions')
@Controller('transactions')
export class TransactionsController {
  private readonly logger = new Logger(TransactionsController.name);

  constructor(private readonly transactionsService: TransactionsService) {}

  @Get('/total-transferred')
  @ApiOperation({
    summary: 'Get total USDC transferred in a given time interval',
    description:
      'Fetches the total amount of USDC transferred within the given time period (in minutes).',
  })
  @ApiQuery({
    name: 'interval',
    type: Number,
    required: true,
    description: 'Time period in minutes (e.g., 5, 10, 30, 40, 60, etc.)',
  })
  @ApiResponse({
    status: 200,
    description: 'Returns the total USDC transferred in the given interval.',
  })
  @ApiResponse({
    status: 400,
    description: 'Bad Request - Invalid interval value.',
  })
  @ApiResponse({
    status: 500,
    description:
      'Internal Server Error - Unexpected failure while fetching data.',
  })
  async getTotalTransferred(@Query('interval') interval: string) {
    try {
      const parsedInterval = parseInt(interval, 10);
      if (isNaN(parsedInterval) || parsedInterval <= 0 || parsedInterval < 5) {
        throw new BadRequestException(
          'Invalid interval. Must be a positive number greater or equal to 5.',
        );
      }

      const totalUSDC =
        await this.transactionsService.getTotalTransferred(parsedInterval);

      return { totalUSDC };
    } catch (error: unknown) {
      this.logger.error('Failed to fetch total transferred USDC', error);

      if (error instanceof BadRequestException) {
        throw error;
      }

      throw new InternalServerErrorException(
        'An unexpected error occurred while fetching total USDC transferred.',
      );
    }
  }

  @Get('top-accounts')
  async getTopAccounts() {
    return await this.transactionsService.getTopAccounts();
  }

  @Get('paginated')
  @ApiOperation({
    summary: 'Get paginated transactions',
    description:
      'Fetches a paginated list of transactions, ordered by timestamp in descending order.',
  })
  @ApiQuery({
    name: 'page',
    required: false,
    example: 1,
    description: 'Page number (default: 1)',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    example: 10,
    description: 'Number of transactions per page (default: 10)',
  })
  @ApiResponse({ status: 200, description: 'Returns paginated transactions' })
  @ApiResponse({ status: 400, description: 'Invalid query parameters' })
  @ApiResponse({ status: 500, description: 'Internal server error' })
  async getPaginatedTransactions(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    try {
      const parsedPage = Number(page);
      const parsedLimit = Number(limit);

      if (
        isNaN(parsedPage) ||
        isNaN(parsedLimit) ||
        parsedPage < 1 ||
        parsedLimit < 1
      ) {
        throw new BadRequestException(
          'Page and limit must be positive integers.',
        );
      }

      return await this.transactionsService.getPaginatedTransactions(
        parsedPage,
        parsedLimit,
      );
    } catch (error: unknown) {
      this.logger.error('Failed to fetch paginated transactions', error);

      if (error instanceof BadRequestException) {
        throw error;
      }

      throw new InternalServerErrorException(
        'An unexpected error occurred while fetching paginated transactions.',
      );
    }
  }

  @Get('largest')
  @ApiOperation({ summary: 'Get largest transactions' })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    example: 10,
    description: 'Number of largest transactions to return (default: 10)',
  })
  @ApiResponse({
    status: 200,
    description: 'Returns the largest transactions sorted by amount.',
  })
  @ApiResponse({
    status: 400,
    description: 'Invalid limit value.',
  })
  @ApiResponse({
    status: 500,
    description: 'Internal server error.',
  })
  async getLargestTransactions(@Query('limit') limit: string) {
    try {
      const parsedLimit = parseInt(limit, 10);
      if (isNaN(parsedLimit) || parsedLimit <= 0) {
        throw new BadRequestException('Limit must be a positive integer.');
      }

      return await this.transactionsService.getLargestTransactions(parsedLimit);
    } catch (error: unknown) {
      this.logger.error('Failed to fetch largest transactions', error);

      if (error instanceof BadRequestException) {
        throw error;
      }

      throw new InternalServerErrorException(
        'An unexpected error occurred while fetching largest transactions.',
      );
    }
  }

  @Get(':hash')
  @ApiOperation({ summary: 'Get transaction details by hash' })
  @ApiParam({
    name: 'hash',
    required: true,
    description: 'Transaction hash to fetch details',
    example:
      '0x805fd751b9db9923985ae916b8319cecd9a9226e55f3282ee281b5cee606e5c1',
  })
  @ApiResponse({ status: 200, description: 'Returns the transaction details.' })
  @ApiResponse({ status: 400, description: 'Invalid transaction hash format.' })
  @ApiResponse({ status: 404, description: 'Transaction not found.' })
  @ApiResponse({ status: 500, description: 'Internal server error.' })
  async getTransactionByHash(@Param('hash') hash: string) {
    try {
      if (!hash || hash.length !== 66) {
        throw new BadRequestException('Invalid transaction hash format.');
      }

      const transaction =
        await this.transactionsService.getTransactionByHash(hash);
      if (!transaction) {
        throw new NotFoundException('Transaction not found.');
      }

      return transaction;
    } catch (error: unknown) {
      if (
        error instanceof BadRequestException ||
        error instanceof NotFoundException
      ) {
        throw error;
      }
      throw new InternalServerErrorException(
        'Failed to fetch transaction details.',
      );
    }
  }
}
